import Vconsole from 'vconsole'
const vConsole = new Vconsole()
export default vConsole