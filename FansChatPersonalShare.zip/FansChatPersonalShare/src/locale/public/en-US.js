export default {
  pp1: "Download FansChat now to find her!",
  pp2: "Online",
  pp3: "Star Bloggers",
  pp4: "Album",
  pp5: "What's New",
  pp6: "PM",
  pp7: "Add as friend",
  pp8: "DOWNLOAD",
  pp9: "friends",
  pp10: "Create the first communication platform for fan bloggers on the whole network",
};
