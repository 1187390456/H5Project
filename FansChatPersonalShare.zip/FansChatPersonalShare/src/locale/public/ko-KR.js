export default {
  "login-switch": "전환에 성공했습니다 !",
  "Index-0": "경로가 작동 중입니다 !",
  "Index-1": "Vuex 작업 중입니다 !",
};
