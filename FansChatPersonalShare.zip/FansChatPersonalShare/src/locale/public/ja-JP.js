export default {
  "login-switch": "切り替えは成功しました !",
  "Index-0": "ルートは機能しています !",
  "Index-1": "Vuex 作業中です !",
};
