export default {
  "login-switch": "Die Umstellung war erfolgreich !",
  "Index-0": "Routing funktioniert !",
  "Index-1": "Vuex Funktioniert !",
};
