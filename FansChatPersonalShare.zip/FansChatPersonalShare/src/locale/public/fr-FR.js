export default {
  "login-switch": "Le passage au numérique a été un succès !",
  "Index-0": "Le routage fonctionne !",
  "Index-1": "Vuex fonctionne !",
};
