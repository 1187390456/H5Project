// import 'proto-polyfill'
module.exports = {
    entry:{
        app:['bable-polyfill','./src/main/js']
    }
}